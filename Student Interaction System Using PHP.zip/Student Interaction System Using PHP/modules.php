<html>
<head>
<title>
catalogue
</title>
<body background="images/black.jpg">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

.collapsible {
  background-image: url("images/black.jpg");;
  color: white;
  cursor: pointer;
  padding: 25px;
  width: 100%;
  border: none;
  text-align: left;
  outline: none;
  font-size: 16px;
}

a, a:visited, a:hover, a:active {
  color: inherit; text-decoration:none;
}


.active, .collapsible:hover {
  background-color: #555;
}
.content {
  padding: 0 18px;
  display: none;
  overflow: hidden;
  background-color: #151517;
}
</style>
</head>
<body>
<button class="collapsible"><a><strong>Study Materials</strong></a></button>
<div class="content">
<br>
  <a href="viewmaterial.php" target="right"><strong><font color="white"><center>View All Materials</center></font></strong></a><br>
  <a href="upload.php" target="right"><strong><font color="white"><center>Upload Material</center></font></strong></a><br>
</div>

<button class="collapsible"><a><strong>Events</strong></a></button>
<div class="content"><br>
  <a href="event/form.php" target="right"><strong><font color="white"><center>Create Events</center></font></strong></a><br>
  <a href="event/read.php" target="right"><strong><font color="white"><center>Register</center></font></strong></a><br>
</div>

<button class="collapsible"><a><strong>Educational Videos</strong></a></button>
<div class="content"><br>
  <a href="video/uploadvideo.php" target="right"><strong><font color="white"><center>Post Video</center></font></strong></a><br>
  <a href="video/viewvideo.php" target="right"><strong><font color="white"><center>Watch Video</center></font></strong></a><br>
</div>

<button class="collapsible"><a href="imagetextmessage/imagetextmsg.php" target="right"><strong>Share News</strong></a></button>
<div class="content"></div>
<button class="collapsible"><a href="imagetextmessage/viewmessage.php" target="right"><strong>what's happening?</strong></a></button>
<div class="content"></div>
<button class="collapsible"><a><strong>Feedback</strong></a></button>
<div class="content"><br>
  <a href="Feedback/imagetextmsg.php" target="right"><strong><font color="white"><center>Post Feedback</center></font></strong></a><br>
  <a href="Feedback/viewmessage.php" target="right"><strong><font color="white"><center>View Feedback</center></font></strong></a><br>
</div>
<button class="collapsible"><a href="TextAnalysis/examples/demo.php" target="right"><strong>Predict Feedback Sentiment</strong></a></button>
<div class="content"></div>





<script>
var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var content = this.nextElementSibling;
    if (content.style.display === "block") {
      content.style.display = "none";
    } else {
      content.style.display = "block";
    }
  });
}
</script>
</body>
</html>