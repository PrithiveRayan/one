<html>
<head>
<style>
#img {
  border: 1px solid black;
  padding: 350px;
  background: url(images/college.jpg);
  background-repeat: no-repeat;
  background-size: 100% 100%;
  
  opacity: 0.9;
  filter: alpha(opacity=50); 
}
a, a:visited, a:hover, a:active {
  color: inherit; text-decoration:none;
}

.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  -webkit-transition-duration: 0.4s; /* Safari */
  transition-duration: 0.4s;
  cursor: pointer;
}

.button5 { border-radius: 14px; font-size: 18px; background-color:#8080ff ; color: black; border: 2px solid black; }

.button5:hover { background-color: white; color: black; }

</style></head>
<body>
<div id="img">
<center><button class="button button5"><a href="login.php">Login </a></button></center>
<center><button class="button button5"><a href="registration.php">Sign Up</a></button></center>
</div>
</body>
</html>