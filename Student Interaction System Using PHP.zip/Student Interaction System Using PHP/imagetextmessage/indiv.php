<?php
  error_reporting(0);
  $conn = mysqli_connect("localhost", "root", "", "sins");
  $rn = $_GET['rn'];
  $sn = $_GET['sn'];
  

include "FaceDetector.php";

$detector = new svay\FaceDetector('detection.dat');
$detector->faceDetect($rn);
$detector->toJpeg();

  
  
?>
