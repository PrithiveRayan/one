<?php
 // Create database connection
	$conn = mysqli_connect("localhost", "root", "", "sins");
 $sql = "SELECT * FROM images";
 $data = mysqli_query($conn,$sql);
 $total = mysqli_num_rows($data);
 $result = mysqli_fetch_all($data,MYSQLI_ASSOC);
 //check records
 if($total != 0){
   echo "";
 }else{
   echo "No records Found";
 }
?>


  <style type="text/css">
   
   .button1 {
  display: inline-block;
  padding: 15px 30px;
  font-size: 12px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  outline: none;
  color: #fff;
  background-color: #4580d9;
  border: none;
  border-radius: 10px;
  box-shadow: 0 5px #999;
}
.button1:hover {background-color:  #1e4b8f}
.button1:active {
  background-color: #121f26;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
textarea {
  width: 100%;
  height: 150px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  font-size: 16px;
  resize: none;
}
#contentdiv {
  background-color: white;
  width: 1000px;
  border: px solid black;
  padding: 50px;
  margin: 10px;
}
   #img_div{
   	width: 1200px;
   	padding: 20px;
   	margin: 20px auto;
   	border: 3px solid #cbcbcb;
   }
   #img_div:after{
   	content: "";
   	display: block;
   	clear: both;
   }
   img{
   	margin: 15px;
   	width: auto;
   	height: auto;
   }
 
</style>
<div id="contentdiv">
            <?php
              //loop starts here
               foreach ($result as $value) { ?>
                
               
					<?php echo "<div id='img_div'>"; ?><br>
					<?php echo "<img src='".$value['image']."' >"; ?><br>
					<?php echo "<p>".$value['text']."</p>";?><br>
					<a href="indiv.php?rn=<?php echo $value['image'];?> 
									 & sn=<?php echo $value['text'];?> 
					id="btn" class="button1" target="_blank">Detect Face</a>
					<?php echo "</div>";?>
                <?php
                 }
                ?>
  </div>