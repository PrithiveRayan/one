<?php
// Create database connection
	$db = mysqli_connect("localhost", "root", "", "sins");
    // Initialize message variable
  $msg = "";

  // If upload button is clicked ...
  if (isset($_POST['upload'])) {
  	
	// image file directory
  	$target = "".basename($_FILES['image']['name']);

	
	
	// Get image name
  	$image = $_FILES['image']['name'];
  	// Get text
  	$text = $_POST['text'];
	
  	$sql = "INSERT INTO images (image, text) VALUES ('$image', '$text')";
  	// execute query
  	mysqli_query($db, $sql);

  	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
  		$msg = "Image uploaded successfully";
  	}else{
  		$msg = "Failed to upload image";
  	}
  }
  $result = mysqli_query($db, "SELECT * FROM images");
?>

<!DOCTYPE html>
<html>
<head>
<title>Image Upload</title>
<style type="text/css">
   
   .button {
  display: inline-block;
  padding: 15px 30px;
  font-size: 12px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  outline: none;
  color: #fff;
  background-color: #4580d9;
  border: none;
  border-radius: 10px;
  box-shadow: 0 6px #999;
}
.button:hover {background-color: #1e4b8f}
.button:active {
  background-color: #121f26;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
textarea {
  width: 100%;
  height: 150px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  font-size: 16px;
  resize: none;
}
#contentdiv {
  background-color: white;
  width: 600px;
  border: 3px solid black;
  padding: 50px;
  margin: 0px;
}
   

   
   #img_div{
   	width: 80%;
   	padding: 5px;
   	margin: 15px auto;
   	border: 1px solid #cbcbcb;
   }
   #img_div:after{
   	content: "";
   	display: block;
   	clear: both;
   }
   img{
   	float: left;
   	margin: 5px;
   	width: 300px;
   	height: 140px;
   }
</style>
</head>
<body>
<br><br><br><br><br><br>
<center>
<div id="contentdiv">
  
  <form method="POST" action="imagetextmsg.php" enctype="multipart/form-data">
  	<input type="hidden" name="size" value="1000000">
	<div>
      <textarea 
      	id="text" 
      	cols="40" 
      	rows="4" 
      	name="text" 
      	placeholder="Write some Message......"></textarea>
  	</div><br>
  	<div align="left">
  	  <input type="file" name="image" required>
  	</div><br>
  	
  	<div>  
  		<center><input type="submit" class="button" name="upload" value="Post"></center>
  	</div>
  </form>
</div></center>
</body>
</html>