<html>
<head>
<title>top</title>
</head>
<body background="images/black.jpg">
<style type="text/css">
.center{
    float:center;
}
.right{
    float:right;
}
a, a:visited, a:hover, a:active {
  color: inherit; text-decoration:none;
}
</style>
<span class="center"><b><strong><font size="7", color="white"><center>Student Interaction System</center></font></strong></span>
<span class="right" style="color:white;font-weight:bold"><a href="logout.php" target="_top">Log Out</span>
</body>
</html>