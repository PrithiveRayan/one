<html>
<head>
<title>Login</title>
</head>
<style type="text/css">
html, 
body {
height: 100%;
}

body {
background-image: url(images/black.jpg);
background-repeat: no-repeat;
background-size: cover;
}
div {
  background-color: white;
  width: 300px;
  border: none;
  padding: 50px;
  margin: 50px;
}
input[type=text],input[type=password], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=submit] {
  width: 100%;
  background-color: #488afa;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
input[type=submit]:hover {
  background-color: #354bdb;
}
div {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 30px;
}
</style>
<body>
<?php
require('db.php');
session_start();
if (isset($_POST['username'])){
	$username = stripslashes($_REQUEST['username']);
	$username = mysqli_real_escape_string($con,$username);
	$password = stripslashes($_REQUEST['password']);
	$password = mysqli_real_escape_string($con,$password);
        $query = "SELECT * FROM `users` WHERE username='$username'
and password='".md5($password)."'";
	$result = mysqli_query($con,$query) or die(mysql_error());
	$rows = mysqli_num_rows($result);
        if($rows==1){
	    $_SESSION['username'] = $username;
	    header("Location: main.php");
         }else{
	header("Location: login.php");
	}
    }else{
?>
<center>
<br><br><br><br><br><br><br><br>
  <div>
    <h1><center>Log-in</center></h1>
  <form action="" method="POST" name="login">
  <input type="text" id="uname" name="username" placeholder="UserName" required="">
  <input type="password" id="pword" name="password" placeholder="Password" required="">  
  <input type="submit" name="submit" value="Login">
  
  </form>
</div>
</center>
<?php } ?>
</body>
</html>