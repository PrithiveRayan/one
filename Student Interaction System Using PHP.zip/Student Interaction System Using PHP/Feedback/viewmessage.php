
  <style type="text/css">
   
   .button {
  display: inline-block;
  padding: 15px 30px;
  font-size: 12px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  outline: none;
  color: #fff;
  background-color: #57859e;
  border: none;
  border-radius: 10px;
  box-shadow: 0 9px #999;
}
.button:hover {background-color: #314e5e}
.button:active {
  background-color: #121f26;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
textarea {
  width: 100%;
  height: 150px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  font-size: 16px;
  resize: none;
}
#contentdiv {
  background-color: white;
  width: 1220px;
  border: 3px solid black;
  padding: 40px;
  margin: 50px;
}
   #img_div{
   	width: 100%;
   	padding: 5px;
   	margin: 15px auto;
   	border: 1px solid #cbcbcb;
   }
   #img_div:after{
   	content: "";
   	display: block;
   	clear: both;
   }
   img{
   	
   	margin: 5px;
   	width: 580px;
   	height: 370px;
   }
</style>
<div id="contentdiv">
  <?php
	$db = mysqli_connect("localhost","root","","sins");
	$sql = "SELECT * FROM fd";
	$result = mysqli_query($db,$sql);
 
    while ($row = mysqli_fetch_array($result)) {
      echo "<div id='img_div'>";
      	echo "<p>"."<strong>"."<h1>".$row['text']."</h1>"."</strong>"."</p>";
      echo "</div>";
    }
  ?>
  </div>