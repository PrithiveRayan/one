<?php include 'filesLogic.php';?>
<!DOCTYPE html>
<html lang="en">

<style type="text/css">  
   .button {
  display: inline-block;
  padding: 15px 30px;
  font-size: 12px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  outline: none;
  color: #fff;
  background-color: #4580d9;
  border: none;
  border-radius: 10px;
  box-shadow: 0 6px #999;
}
.button:hover {background-color: #1e4b8f}
.button:active {
  background-color: #121f26;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
input {
  width: 90%;
  border: 1px solid #f1e1e1;
  display: block;
  padding: 5px 10px;
}
#contentdiv {
  background-color: white;
  width: 600px;
  border: 3px solid black;
  padding: 50px;
  margin: 0px;
}

</style>



  <head>
    <link rel="stylesheet" href="studystyle1.css">
    <title>Files Upload and Download</title>
  </head>
  <body>
    <div class="container">
	<br><br><br><br><br><br><br><br>
	<center>
      <div id="contentdiv">
        <form action="upload.php" method="post" enctype="multipart/form-data" >
          <h3>Upload File</h3>
          <input type="file" name="myfile"> <br><br>
          <center><button type="submit" class="button" name="save">upload</button></center>
        </form>
      </div>
	  </center>
    </div>
  </body>
</html>