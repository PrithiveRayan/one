<?php include 'filesLogic.php';?>
<!DOCTYPE html>
<html>
<style type="text/css">
   .button1 {
  display: inline-block;
  padding: 10px 25px;
  font-size: 12px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  outline: none;
  color: #fff;
  background-color: #4580d9;
  border: none;
  border-radius: 10px;
  box-shadow: 0 5px #999;
}
.button1:hover {background-color:  #1e4b8f}
.button1:active {
  background-color: #121f26;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
textarea {
  width: 100%;
  height: 150px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  font-size: 16px;
  resize: none;
}
</style>
<head>
  <meta charset="utf-8" />
  <link rel="stylesheet" href="studystyle.css">
  <title>Download files</title>
</head>
<body>

<table>
<thead>
    
    <th>Filename</th>
    <th>size </th>
    <th>Downloads</th>
    <th>Action</th>
</thead>
<tbody>
  <?php foreach ($files as $file): ?>
    <tr>
      
      <td><center><?php echo $file['name']; ?></center></td>
      <td><center><?php echo floor($file['size'] / 1000) . ' KB'; ?></center></td>
      <td><center><?php echo $file['downloads']; ?></center></td>
      <td><center><a href="viewmaterial.php?file_id=<?php echo $file['id'] ?>" id="btn" class="button1">Download</a></center></td>
    </tr>
  <?php endforeach;?>

</tbody>
</table>

</body>
</html>