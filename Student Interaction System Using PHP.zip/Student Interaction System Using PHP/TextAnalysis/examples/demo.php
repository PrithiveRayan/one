  <style type="text/css">
   

textarea {
  width: 100%;
  height: 150px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  font-size: 16px;
  resize: none;
}
#contentdiv {
  background-color: white;
  width: 1220px;
  border: 3px solid black;
  padding: 40px;
  margin: 50px;
}
   

   
   #img_div{
   	width: 95%;
   	padding: 5px;
   	margin: 25px auto;
   	border: 2px solid #cbcbcb;
   }
   #img_div:after{
   	content: "";
   	display: block;
   	clear: both;
   }
   img{
   	margin: 5px;
   	width: 800px;
   	height: 500px;
   }
</style>

<div id="contentdiv">
<?php
	$db_host     = "localhost";
    $db_username = "root";
    $db_password = "";

	$db = mysqli_connect($db_host, $db_username, $db_password) or die("Error " .mysqli_error());
	$dbselect = mysqli_select_db($db, "sins") or die("Error " . mysqli_error());
	$sql = mysqli_query($db, "SELECT * FROM fd");
	
	while($row = mysqli_fetch_array($sql)){
		$messages[] = $row['text'];
	}
	


if (PHP_SAPI != 'cli') {
	echo "<pre>";
}

require_once __DIR__ . '/../autoload.php';
$sentiment = new \PHPInsight\Sentiment();
foreach ($messages as $string) {

	// calculations:
	$scores = $sentiment->score($string);
	$class = $sentiment->categorise($string);

	// output:
	
	echo "<div id='img_div'>";
	echo "Feedback: $string\n";
	echo "Dominant: $class, scores: ";
	print_r($scores);
	echo "\n";
	echo "</div>";

}
?>
</div>


