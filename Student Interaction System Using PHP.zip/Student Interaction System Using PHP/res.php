<html>
<head>
<title>
Main
</title>
</head>
<body background="grey.jpg">
<style type="text/css">

body {
background-image: url(images/black.jpg);
background-repeat: no-repeat;
background-size: cover;
}


table.one {border-collapse:collapse;}
img.top{vertical-align:text-top;}
a:hover {color: red}
a{text-decoration:none;}
td.a {
border-style:groove;
border-top-style:none;
border-left-style:none;
border-right-style:none;
border-width:500%;
border-color:#000000;
padding: 50px;
}
</style><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<a> <center><font size=10>WELCOME</font></center></a>

</body>
</html>
