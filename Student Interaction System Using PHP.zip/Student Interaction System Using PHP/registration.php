<html>
<head>
<title>Registration</title>
<style type="text/css">
html, 
body {
height: 100%;
}
body {
background-image: url(images/black.jpg);
background-repeat: no-repeat;
background-size: cover;
}
div {
  background-color: white;
  width: 300px;
  border: none;
  padding: 50px;
  margin: 50px;
}
input[type=text],input[type=email],input[type=password], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=submit] {
  width: 100%;
  background-color: #488afa;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
input[type=submit]:hover {
  background-color: #354bdb;
}
div {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 70px;
}
</style>
</head>
<body>
<?php
require('db.php');
if (isset($_REQUEST['username'])){
	$username = stripslashes($_REQUEST['username']);
	$username = mysqli_real_escape_string($con,$username); 
	$email = stripslashes($_REQUEST['email']);
	$email = mysqli_real_escape_string($con,$email);
	$password = stripslashes($_REQUEST['password']);
	$password = mysqli_real_escape_string($con,$password);
	$trn_date = date("Y-m-d H:i:s");
        $query = "INSERT into `users` (username, password, email, trn_date)
VALUES ('$username', '".md5($password)."', '$email', '$trn_date')";
        $result = mysqli_query($con,$query);
        if($result){
            header("Location: login.php");
        }
    }else{
?>


<center>
      <div  class="form">
	  <h1><center>Sign-Up</center></h1>
        <form action="" id="contactform" method="POST"> 
          <p align="left" class="contact"><label for="name">Name</label></p> 
          <input id="name" name="username" placeholder="Username" required="" tabindex="1" type="text" > 
           
          <p align="left" class="contact"><label for="email">Email</label></p> 
          <input id="email" name="email" placeholder="example@domain.com" required="" type="email" > 
                          
          <p align="left" class="contact"><label for="password">Password</label></p> 
          <input type="password" id="password" name="password" required=""> 
          <input class="buttom" name="submit" id="submit" tabindex="5" value="Register" type="submit"> 
<br>
<p><a href="homepage.php">Back to Homepage</a></P>		  
   </form> 
</div>  


<?php } ?>
</body>
</html>