<?php
   $host = "localhost";
   $username = "root";
   $password = "";
   $dbname = "sins";
   // connection
   $con = mysqli_connect($host,$username,$password,$dbname);
   //check
   if($con){
       echo "";
   }else{
       die("Connection Failed :". mysqli_connect_error());
   }
?>