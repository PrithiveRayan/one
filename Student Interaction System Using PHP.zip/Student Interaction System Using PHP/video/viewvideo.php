   <style type="text/css"> 
   #img_div{
   	width: 48%;
   	padding: 7px;
   	margin: 20px auto;
   	border: 5px solid #cbcbcb;
   }
</style>
 
 
 <?php
	$db = mysqli_connect("localhost","root","","sins");
	$sql = "SELECT * FROM video";
	$result = mysqli_query($db,$sql);
 
    while ($row = mysqli_fetch_array($result)) {
		echo "<div id='img_div'>";
      	echo "<video width='660' height='500' controls><source src='test_upload/".$row['video_name']."' ></video>";
		echo "<p>".$row['video_name']."</p>";
		echo "</div>";
	}
	?>
  
    