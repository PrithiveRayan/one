<?php
  include("videodbconfig.php");
?>
<?php

error_reporting(1);
extract($_POST);
$target_dir = "test_upload/";

$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);

if($upd)
{
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

if($imageFileType != "mp4" && $imageFileType != "avi" && $imageFileType != "mov" && $imageFileType != "3gp" && $imageFileType != "mpeg")
{
    echo "File Format Not Suppoted";
} 

else
{

$video_path=$_FILES['fileToUpload']['name'];

$con->query("insert into video(video_name) values('$video_path')");
move_uploaded_file($_FILES["fileToUpload"]["tmp_name"],$target_file);
echo "uploaded ";
}
}

//display all uploaded video

?>
<!DOCTYPE html>
<html>
<head>
<title>Video Upload</title>
<style type="text/css">
      .button {
  display: inline-block;
  padding: 15px 30px;
  font-size: 12px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  outline: none;
  color: #fff;
  background-color: #4580d9;
  border: none;
  border-radius: 10px;
  box-shadow: 0 6px #999;
}
.button:hover {background-color: #1e4b8f}
.button:active {
  background-color: #121f26;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
textarea {
  width: 100%;
  height: 150px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  font-size: 16px;
  resize: none;
}
#contentdiv {
  background-color: white;
  width: 600px;
  border: 3px solid black;
  padding: 50px;
  margin: 0px;
}
  
</style>
</head>
<body>
<br><br><br><br><br><br>
<center>
<div id="contentdiv">
  
  <form method="post" enctype="multipart/form-data">
  
  <input type="file" name="fileToUpload"/><br><br>
  
  <input type="submit" class="button" value="Uplaod Video" name="upd"/>
  <input type="submit" class="button" value="Display Video" name="disp"/>
  </form>
</div></center>
</body>
</html>