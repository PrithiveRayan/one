<?php
 include("connection.php");
 $sql = "SELECT * FROM finsert";
 $data = mysqli_query($conn,$sql);
 $total = mysqli_num_rows($data);
 $result = mysqli_fetch_all($data,MYSQLI_ASSOC);
 //check records
 if($total != 0){
   echo "";
 }else{
   echo "No records Found";
 }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Evetns</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" 
    integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <style>
      .table > tbody > tr > td{
        vertical-align:middle;
      }
    </style>       
</head>

<body>
  <div class="container pt-3">
   <h3 class="text-center">Upcoming Events</h3><br>
    <div class="row text-center">
      <div class="col-lg-12">
        <table class="table table-bordered table-striped">
          <thead>
            <tr>
              <th>Events</th>
              <th colspan="2">Ticket</th>
            </tr>
         </thead>
         <tbody>
            <?php
              //loop starts here
               foreach ($result as $value) { ?>
                  <tr>
                    <td>Event Name: <?php echo $value['eventname']; ?><br>
					Date :<?php echo $value['datetime']; ?><br>
					Time :<?php echo $value['time']; ?><br>
					Organizer Name :<?php echo $value['orgname']; ?><br>
					Contact Number :<?php echo $value['number']; ?><br>
					Email :<?php echo $value['email']; ?><br>
					Description :<?php echo $value['description']; ?><br>
					</td>
					<td><a href="qrcode.php?rn=<?php echo $value['eventname'];?> 
					& datetime=<?php echo $value['datetime'];?> 
					& cl=<?php echo $value['time'];?> 
					& ol=<?php echo $value['orgname'];?> 
					& nl=<?php echo $value['number'];?>
					& el=<?php echo $value['email'];?>
					& dl=<?php echo $value['description'];?>"
					class="btn btn-primary btn-sm">Book Ticket</a></td>
                    
                    
                 </tr>
                <?php
                 }
                ?>     
          </tbody>           
     </table>
    <div>
 </div><!-- row -->
</div><!-- container -->
<script type="text/javascript">
   function checkDelete(){
      return confirm("Are you sure that you want to delete this record?");
   }
</script>
</body>
</html>