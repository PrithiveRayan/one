<?php
  error_reporting(0);
  include("connection.php");
  $rn = $_GET['rn'];
  $datetime = $_GET['datetime'];
  $cl = $_GET['cl'];
  $ol = $_GET['ol'];
  $nl = $_GET['nl'];
  $el = $_GET['el'];
  $dl = $_GET['dl']; 
?>


<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Book Ticket</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" 
    integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
   <link rel="stylesheet" type="text/css"  href="eventcss.css" />
</head>
<body>
  <div class="container-fluid px-5">
    <div class="row">
      <div class="col-lg-4"></div>
       <div class="col-lg-4 form-container">
         <h4 class="text-center"><?php echo $rn;?> </h4>
         <!-- form start here -->
          <form method="post" action="show.php" enctype="multipart/form-data">

		  <input type="text" autocomplete="off" class="form-control" name="text" style="border-radius: 0px; " 
		  value="<?php echo $rn;?>">
          <br>
           <!-- submit button -->
           <input type="submit" class="btn btn-info btn-block" name="submit" value="Generate">
         </form>
       </div>
       <div class="col-lg-4"></div>
    </div><!-- row closed -->
</div><!-- container closed --> 

<?php

if (isset($_POST['text'])) {
    $text = $_POST['text'];
}

?>
</body>
</html>