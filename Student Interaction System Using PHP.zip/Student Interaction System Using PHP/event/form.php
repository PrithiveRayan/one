<?php
  include("connection.php");
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>event_creation</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- bootstrap css -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" 
    integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <!-- custom css -->
    <link rel="stylesheet" type="text/css"  href="eventcss.css" />
</head>

<body>
  <div class="container">
    <div class="row">
      <div class="col-lg-4"></div>
       <div class="col-lg-4 form-container">
         <h4 class="text-center">Create Event</h4>
         <!-- form start here -->
          <form method="post" action="" enctype="multipart/form-data">
          <div class="form-group">
           <label>Event Name</label>
           <input class="form-control"  type="text" name="eventname" placeholder="">
          </div>
          
          <div class="form-group">
           <label>Date</label>
           <input class="form-control"  type="text" name="datetime" placeholder="DD/MM/YYYY">
          </div>
		  
		  <div class="form-group">
           <label>Time</label>
           <input class="form-control"  type="text" name="time" placeholder="00:00 AM/PM">
          </div>
		  <div class="form-group">
           <label>Organizer Name</label>
           <input class="form-control"  type="text" name="orgname" placeholder="">
          </div>
		  <div class="form-group">
           <label>Contact Number</label>
           <input class="form-control"  type="text" name="number" placeholder="">
          </div>
		  <div class="form-group">
           <label>email</label>
           <input class="form-control"  type="text" name="email" placeholder="">
          </div>
		  
          <div class="form-group">
           <label>Description</label>
           <input class="form-control"  type="text" name="description" placeholder="">
          </div>
           
          <!-- submit button -->
           <input type="submit" class="btn btn-primary btn-block" name="submit" value="Create">
         </form>
       </div>
       <div class="col-lg-4"></div>
    </div><!-- row closed -->
</div><!-- container closed --> 

 <?php
    if($_SERVER["REQUEST_METHOD"] == "POST"){
      //getting form input values
       $eventname = $_POST["eventname"];
       $dt = $_POST["datetime"];
	   $time = $_POST["time"];
	   $orgname = $_POST["orgname"];
	   $number = $_POST["number"];
	   $email = $_POST["email"];
       $description = $_POST["description"];
 

      //validation
      if($eventname!= "" && $dt!= "" && $time!= "" && $orgname!= "" && $number!= "" && $email!= "" && $description!= ""){
        // sql statement
        $sql = "INSERT INTO finsert (eventname, datetime, time, orgname, number, email, description) VALUES ('$eventname','$dt','$time','$orgname','$number','$email','$description')";
        $data = mysqli_query($conn,$sql);
         if($data){
          echo "<p class='text-center success-text mt-2'>Your details have been submitted</p>";
         }
      }
      else{
        echo "<p class='text-center error-text mt-2'>*All fields are Required</p>";
      }
    }
?>
</body>
</html>