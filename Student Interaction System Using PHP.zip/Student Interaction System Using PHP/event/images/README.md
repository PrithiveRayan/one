# PHP-MySQL
 
<h4><center>1. Insert data into database</center></h4>
<img src="Insert_Data.png">

<h4><center>2. Display data from database</center></h4>
<img src="Read_Data_1.png">

<h4><center>3. Update data from database</center></h4>
<img src="Update_data.png">

<h4><center>4. Delete data from database</center></h4>
<img src="delete_data.png">
