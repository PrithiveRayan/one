<?php
 include("connection.php");
 $sql = "SELECT * FROM finsert";
 $data = mysqli_query($conn,$sql);
 $total = mysqli_num_rows($data);
 $result = mysqli_fetch_all($data,MYSQLI_ASSOC);
 //check records
 if($total != 0){
   echo "";
 }else{
   echo "No records Found";
 }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Read Data</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" 
    integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <style>
      .table > tbody > tr > td{
        vertical-align:middle;
      }
    </style>       
</head>

<body>
  <div class="container pt-3">
   <h3 class="text-center"></h3><br>
    <div class="row text-center">
      <div class="col-lg-12">
        <table class="table table-bordered table-striped">
          <thead>
		  <?php
		   foreach ($result as $value) { ?>
            <tr>
              <th><font size="6"><?php echo $value['eventname']; ?></font></th>
            </tr>
			<?php
		   }
		   ?>
         </thead>
         <tbody>
            <?php
              //loop starts here
               foreach ($result as $value) { ?>
                  <tr>
                    <td>
					<a>Date :</a><?php echo $value['datetime']; ?><br>
					<a>Time :</a><?php echo $value['time']; ?><br>
					<a>Organizer Name :</a><?php echo $value['orgname']; ?><br>
					<a>Contact Number :</a><?php echo $value['number']; ?><br>
					<a>Email Id :</a><?php echo $value['email']; ?><br>
					<a>Description :</a><?php echo $value['description']; ?>
					</td>
                    
                 </tr>
                <?php
                 }
                ?>     
          </tbody>           
     </table>
    <div>
 </div><!-- row -->
</div><!-- container -->
<script type="text/javascript">
   function checkDelete(){
      return confirm("Are you sure that you want to delete this record?");
   }
</script>
</body>
</html>