<?php
  error_reporting(0);
  include("connection.php");
  $rn = $_GET['rn'];
  $nm = $_GET['sn'];
  $cl = $_GET['cl'];
  $ol = $_GET['ol'];
  $nl = $_GET['nl'];
  $el = $_GET['el'];
  $dl = $_GET['dl']; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Generate QR Code</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
    <style>
        body, html {
            height: 100%;
            width: 100%;
        }
        .bg {
            background-image: url("imagess/bg.jpg");
            height: 100%;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }
		
		.button {
  display: inline-block;
  padding: 15px 235px;
  font-size: 12px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  outline: none;
  color: #fff;
  background-color: #4580d9;
  border: none;
  border-radius: 10px;
  box-shadow: 0 6px #999;
}
.button:hover {background-color: #1e4b8f}
.button:active {
  background-color: #121f26;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
    </style>
</head>
<body class="bg">
    <div class="container" id="panel">
        <br><br><br>
        <div class="row">
            <div class="col-md-6 offset-md-3" style="background-color: white; padding: 20px; box-shadow: 10px 10px 5px #888;">
                <div class="panel-heading">
                    <h1>Generate QR-code</h1>
                </div>
                <hr>
                <form action="show.php" method="get">
                    Number Of Tickets:<input type="text" autocomplete="off" class="form-control" name="text" style="border-radius: 0px; " 
					value="Count :
					<?php echo $qq;?>
					<?php echo $qq;?>
					
					/Event_Name :<?php echo $rn;?>/
					Date :<?php echo $datetime;?>/
					Time :<?php echo $cl;?>/
					Organizer_Name :<?php echo $ol;?>/
					Number :<?php echo $nl;?>/
					Email :<?php echo $el;?>/
					Description :<?php echo $dl;?>">
                    <br>
                    <center><input type="submit" class="button" value="Generate"></center>
                </form>
            </div>
        </div>
    </div>
</body>
</html>