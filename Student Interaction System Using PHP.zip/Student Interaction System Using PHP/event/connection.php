<?php
   $host = "localhost";
   $username = "root";
   $password = "";
   $dbname = "sins";
   // connection
   $conn = mysqli_connect($host,$username,$password,$dbname);
   //check
   if($conn){
       echo "";
   }else{
       die("Connection Failed :". mysqli_connect_error());
   }
?>