<?php
session_start();
?>
<html>
<head>

<title>Student Interaction System</title>
<frameset rows="12%,*" frameborder=no >
<frame name="top" src="top.php"/>
<frameset cols="17%,*">
<frame name="left" src="modules.php"/>
<frame name="right" src="res.php"/>
</frameset>
</head>
</html>